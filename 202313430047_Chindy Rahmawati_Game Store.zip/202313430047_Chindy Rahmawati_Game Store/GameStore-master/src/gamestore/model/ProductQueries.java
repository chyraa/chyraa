// PreparedStatements digunakan di aplikasi GameSpot.
package gamestore.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductQueries {
    private static final String URL = "jdbc:mysql://localhost/gamestore_fx_db";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    
    private Connection connection; // manages the connection
    private PreparedStatement selectAllProducts;
    private PreparedStatement selectAlreadyPurchasedProducts;
    
    // Constructor
    public ProductQueries() {
        try {
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            
            // membuat kueri untuk semua catatan dalam tabel Produk
            selectAllProducts = connection.prepareStatement("SELECT * FROM products");
                        
            // membuat kueri untuk semua produk yang telah dibeli
            selectAlreadyPurchasedProducts = connection.prepareStatement("SELECT ProductID FROM orders WHERE CustomerID = ?");
            
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
            System.exit(1);
        }
    }
    
    public List<Product> getAllProducts() {
        List<Product> results = null;
        ResultSet resultSet = null;
        
        try {
        // executeQuery mengembalikan ResultSet yang berisi catatan yang diinginkan.
        resultSet = selectAllProducts.executeQuery();
        results = new ArrayList<Product>();
        while (resultSet.next()) {
            results.add(new Product(
                    resultSet.getInt("productID"),
                    resultSet.getString("title"),
                    resultSet.getDouble("price"),
                    resultSet.getString("description"),
                    resultSet.getString("video"),
                    resultSet.getString("platform"),
                    resultSet.getString("cover"),
                    resultSet.getString("image1"),
                    resultSet.getString("image2"),
                    resultSet.getString("image3"),
                    resultSet.getString("image4"),
                    resultSet.getString("exeFile")
            ));
        }
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } finally {
            try {
                resultSet.close();
            } catch (SQLException sqlException) {
                sqlException.printStackTrace();
                close();
            }
        }
        
        return results;
    }
    
    public List<Integer> getAlreadyPurchasedProducts(int customerID) {
        List<Integer> results = null;
        ResultSet resultSet = null;
        
        try {
            selectAlreadyPurchasedProducts.setInt(1, customerID);
            
            // executeQuery mengembalikan ResultSet dengan semua catatan yang diinginkan.
            resultSet = selectAlreadyPurchasedProducts.executeQuery();
            
            results = new ArrayList<Integer>();
            
            while(resultSet.next()) {
                int productID = resultSet.getInt("productID");
                results.add(productID);
            }
            
        } catch(SQLException sqlException) {
            sqlException.printStackTrace();
            
        } finally {
            try {
                resultSet.close();
            } catch (SQLException sqlException) {
                sqlException.printStackTrace();
                close();
            }
        }
        
        return results;
    }
    
    // tutup koneksi ke database
    public void close() {
        try {
            connection.close();
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }
    }
}