-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 19, 2023 at 04:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gamestore_fx_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `CustomerID` int(11) NOT NULL,
  `UserName` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `CCNumber` varchar(16) DEFAULT NULL,
  `Balance` double DEFAULT 50
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CustomerID`, `UserName`, `Email`, `Password`, `CCNumber`, `Balance`) VALUES
(1, 'Chindy', 'chindy@gmail.com', '123456', '1122334455667788', 15),
(2, 'Naufal', 'naufal@gmail.com', '123456', '1234567891234567', 43);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `Quantity` tinyint(4) DEFAULT 1,
  `ProductID` int(11) DEFAULT NULL,
  `CustomerID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `Quantity`, `ProductID`, `CustomerID`) VALUES
(1, 1, 11, 1),
(2, 1, 9, 1),
(3, 1, 3, 1),
(4, 1, 4, 1),
(5, 1, 10, 2),
(6, 1, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductID` int(11) NOT NULL,
  `Title` varchar(45) DEFAULT NULL,
  `Price` double(5,2) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Video` varchar(45) DEFAULT NULL,
  `Platform` enum('Windows','Linux') DEFAULT NULL,
  `Cover` varchar(55) DEFAULT NULL,
  `Image1` varchar(55) DEFAULT NULL,
  `Image2` varchar(55) DEFAULT NULL,
  `Image3` varchar(55) DEFAULT NULL,
  `Image4` varchar(55) DEFAULT NULL,
  `ExeFile` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductID`, `Title`, `Price`, `Description`, `Video`, `Platform`, `Cover`, `Image1`, `Image2`, `Image3`, `Image4`, `ExeFile`) VALUES
(1, 'Zombie Apocalypse', 7.00, 'Setelah bencana teknologi, sebagian besar populasi dunia berubah menjadi zombie. Kota-kota hancur, tetapi sebagian kecil orang selamat dan sekarang bersembunyi di tempat perlindungan. Anda adalah salah satu yang selamat. Tugas Anda adalah melindungi tempat perlindungan Anda dari kerumunan zombie dan mutan haus darah. Anda memiliki berbagai senjata dan peningkatan yang luas untuk digunakan. Anda juga dapat meningkatkan barikade di pintu masuk tempat perlindungan atau membuat menara senapan mesin yang sangat efisien melawan kerumunan musuh. Fitur permainan: 45 level, 4 jenis senjata dan peningkatan, 4 jenis peningkatan untuk tempat perlindungan Anda, 7 jenis musuh. Musik atmosfer dan efek suara.', 'https://www.youtube.com/watch?v=jKTWSDOydww', 'Windows', '/resources/images/covers/zombie-apocalypse-cover.png', '/resources/images/zombie-apocalypse-1.jpg', '/resources/images/zombie-apocalypse-2.jpg', '/resources/images/zombie-apocalypse-3.jpg', '/resources/images/zombie-apocalypse-4.jpg', 'http://www.gametop.com/download-free-games/zombie-apocalypse/download.html'),
(2, 'City Racing', 5.00, 'City Racing adalah permainan balap mobil gaya GTA yang sangat populer. Permainan ini memberi Anda kebebasan untuk menjelajahi kota dengan cara apa pun yang Anda inginkan. Anda dapat ikut dalam balap jalanan ilegal, memenangkan uang, melakukan aksi melompat spektakuler, meng-upgrade mobil Anda untuk mengalahkan lawan balap Anda, atau Anda juga bisa bekerja sebagai sopir taksi. Gameplay-nya mudah, Anda hanya perlu refleks cepat dan mata yang baik untuk menghindari mobil polisi dan menghasilkan uang. Unduh versi lengkap permainan balap ini sekarang dan cobalah bertahan hidup di kota besar.', 'https://www.youtube.com/watch?v=3yFZk5SxFgg', 'Windows', '/resources/images/covers/city-racing-cover.jpg', '/resources/images/city-racing-1.jpg', '/resources/images/city-racing-2.jpg', '/resources/images/city-racing-3.jpg', '/resources/images/city-racing-4.jpg', 'http://www.gametop.com/download-free-games/city-racing/download.html'),
(3, 'Alien Shooter', 6.00, 'Kegelapan yang tak berujung dan lorong-lorong panjang yang suram dari kompleks militer telah menjadi tempat kediaman kejahatan, karena ribuan makhluk haus darah mengisi kantor-kantor, gudang-gudang, dan laboratorium-laboratorium misteriusnya. Misi Anda sederhana: bersihkan pangkalan itu dengan segala cara. Anda akan diberikan bahan peledak untuk membantu Anda mendapatkan akses ke teleportasi dari mana ribuan makhluk tanpa belas kasihan tumpah. Meriam berdiri akan membantu dalam pertahanan daerah tersebut. Anda telah diberi akses ke teknologi senjata paling canggih yang uang bisa beli. Saat Anda mendapatkan bayaran, Anda dapat melengkapi diri dengan senjata tambahan di area persenjataan dan implantasi biomekanik yang akan membuat kemampuan bertarung Anda menjadi super manusia. Invasi alien telah dimulai, kita hanya punya satu kesempatan, yaitu menghentikan mereka di tempat persiapan mereka. Jangan biarkan mereka melarikan diri dari fasilitas ini, Anda adalah harapan terakhir kita. Nasib kemanusiaan sekarang bergantung pada Anda! Unduh permainan gratis hari ini dan terjun ke tengah-tengah perang di Alien Shooter, sebuah permainan aksi cepat.', 'https://www.youtube.com/watch?v=vR9706AMq8M', 'Windows', '/resources/images/covers/alien-shooter-cover.jpg', '/resources/images/alien-shooter-1.jpg', '/resources/images/alien-shooter-2.jpg', '/resources/images/alien-shooter-3.jpg', '/resources/images/alien-shooter-4.jpg', 'http://www.gametop.com/download-free-games/alien-shooter/download.html'),
(4, 'Crazy Cars', 4.00, 'Temukan kembali sensasi murni bermain game arcade dengan game balap menakjubkan ini, mengambil tikungan dengan kecepatan maksimum atau melompat besar yang bisa mencapai ratusan meter tingginya. Anda akan berada tepat di tengah-tengah semua aksi, balapan dengan beberapa mobil terbaik di luar sana. Melintasi negara bagian yang berbeda di Amerika Serikat dengan kecepatan lebih dari 180 mph! Pastikan saja polisi tidak menangkap Anda.', 'https://www.youtube.com/watch?v=tmHm_sULlzk', 'Windows', '/resources/images/covers/crazy-cars-cover.jpg', '/resources/images/crazy-cars-1.jpg', '/resources/images/crazy-cars-2.jpg', '/resources/images/crazy-cars-3.jpg', '/resources/images/crazy-cars-4.jpg', 'http://www.gametop.com/download-free-games/crazy-cars/download.html'),
(5, 'Desert Hawk', 8.00, 'Pusat perhatian dari permainan gratis ini adalah markas teroris baru, yang sangat baik dipertahankan dan dirancang dengan cerdas untuk membuat serangan langsung tidak bermakna. Kali ini, para teroris menciptakan senjata monster baru dan jenis bahan peledak baru. Tentu saja, satu-satunya cara untuk menghentikan kehancuran adalah dengan memusnahkan lawan saat mereka bergerak. Setelah itu dilakukan, pemain harus merencanakan serangan dengan hati-hati ke pusat markas yang dipertahankan oleh menara-menara dan diperkuat dengan jenis paduan logam baru. Dengan grafis yang luar biasa, musik latar yang menggugah, dan beberapa aksi paling menarik yang pernah kami tawarkan, game pc versi lengkap ini yang dapat diunduh secara gratis merupakan misi baru yang berani untuk para pecinta game arcade.', 'https://www.youtube.com/watch?v=czJmb6QDiik', 'Windows', '/resources/images/covers/desert-hawk-cover.jpg', '/resources/images/desert-hawk-1.jpg', '/resources/images/desert-hawk-2.jpg', '/resources/images/desert-hawk-3.jpg', '/resources/images/desert-hawk-4.jpg', 'http://www.gametop.com/download-free-games/desert-hawk/download.html'),
(6, 'Fall Of The New Age', 12.00, 'Bantu Marla mengungkap rahasia gelap sebuah kultus abad pertengahan dalam \"Fall of the New Age\". Kultus tersebut berencana mengendalikan semua warga dan menghancurkan semua pengetahuan dan budaya. Dunia abad pertengahan asli untuk dijelajahi dengan lebih dari 40 lokasi yang luar biasa rinci. Puluhan mini game dan tantangan yang memutar otak. Animasi indah dalam grafik 3D. \"Fall of the New Age\" adalah petualangan fantastis yang akan membuat Anda terpikat sejak awal.', 'https://www.youtube.com/watch?v=5pLNDqbMawg', 'Windows', '/resources/images/covers/fall-of-the-new-age-cover.jpg', '/resources/images/fall-of-the-new-age-1.jpg', '/resources/images/fall-of-the-new-age-2.jpg', '/resources/images/fall-of-the-new-age-3.jpg', '/resources/images/fall-of-the-new-age-4.jpg', 'http://www.gametop.com/download-free-games/fall-of-the-new-age/download.html'),
(7, 'Football World', 3.50, 'Football World adalah simulator sepak bola yang sangat baik. Mainkan untuk lebih dari 70 negara. Pilih tim Anda dan menangkan Piala Dunia. Grafis 3D modern, suara realistis, dan AI yang menantang.', 'https://www.youtube.com/watch?v=v4FeUs81MLU', 'Windows', '/resources/images/covers/football-world-cover.jpg', '/resources/images/football-world-1.jpg', '/resources/images/football-world-2.jpg', '/resources/images/football-world-3.jpg', '/resources/images/football-world-4.jpg', 'http://www.gametop.com/download-free-games/football-world/download.html'),
(8, 'Frontline Tactics', 9.00, 'Permainan taktik militer yang sangat adiktif dengan mode multipemain lintas platform melalui berbagai rilis desktop dan mobile. Frontline Tactics memungkinkan Anda memimpin unit tempur modern, elit, melalui berbagai misi, mulai dari pertahanan dan pengendalian lokasi atau aset hingga eliminasi total dan bertahan hidup. Persenjatai tentara Anda dengan senjata modern, baju besi, dan peralatan, serta berikan keterampilan kepada mereka untuk berhasil di medan perang.', 'https://www.youtube.com/watch?v=vHqXjzFgm-A', 'Windows', '/resources/images/covers/frontline-tactics-cover.jpg', '/resources/images/frontline-tactics-1.jpg', '/resources/images/frontline-tactics-2.jpg', '/resources/images/frontline-tactics-3.jpg', '/resources/images/frontline-tactics-4.jpg', 'http://www.gametop.com/download-free-games/frontline-tactics/download.html'),
(9, 'Invention', 11.00, '\"Invention\" adalah permainan penembak orang pertama 3D dengan elemen RPG. Aksi dalam permainan ini berlangsung di sebuah pulau misterius di dalam laboratorium rahasia. Di laboratorium ini, orang-orang yang dulunya bekerja mencoba memberikan kemampuan super kepada orang lain. Namun, mereka tidak bisa membayangkan ke mana eksperimen ini akan membawa. Pahlawan masuk ke sana sebagai hasil dari kecelakaan. Dalam pencarian bantuan, dia menemukan laboratorium tersebut. Tanpa mengetahui apa yang ada di dalamnya, dia turun ke sana...', 'https://www.youtube.com/watch?v=tmhZy3JJV-M', 'Windows', '/resources/images/covers/invention-cover.jpg', '/resources/images/invention-1.jpg', '/resources/images/invention-2.jpg', '/resources/images/invention-3.jpg', '/resources/images/invention-4.jpg', 'http://www.gametop.com/download-free-games/invention/download.html'),
(10, 'Super Bikes', 7.00, 'Ikutlah dalam kompetisi balap sepeda motor terhebat dalam permainan balap sepeda motor 3D ini. Berlatihlah dalam mode Single Race atau bersaing dengan hasil terbaik Anda dalam mode Time Attack. Lakukan trik untuk mendapatkan poin dan sampai tepat waktu di garis finish. Unduh versi lengkap permainan hari ini dan ikut serta dalam kompetisi balap sepeda motor terhebat. Fitur Permainan: - Permainan balap sepeda motor nyata; - Grafis 3D modern; - Gameplay yang luar biasa adiktif; - Soundtrack asli dan efek suara yang kuat; - Pilihan Simpan / Muat permainan; - Statistik permainan.', 'https://www.youtube.com/watch?v=oALZsm7XYho', 'Windows', '/resources/images/covers/super-bikes-cover.jpg', '/resources/images/super-bikes-1.jpg', '/resources/images/super-bikes-2.jpg', '/resources/images/super-bikes-3.jpg', '/resources/images/super-bikes-4.jpg', 'http://www.gametop.com/download-free-games/superbikes/download.html'),
(11, 'StarCraft', 9.00, 'Sebuah permainan strategi waktu nyata fiksi ilmiah, StarCraft berlatar di sektor jauh dari galaksi Bima Sakti. Cerita permainan berpusat pada munculnya dua ras alien di ruang Terran, dan upaya masing-masing ras untuk bertahan dan beradaptasi di atas yang lain. Pemain mengasumsikan tiga peran sepanjang tiga kampanye: seorang gubernur kolonial Konfederasi yang menjadi komandan revolusioner, seorang Zerg cerebrate yang mendorong doktrin asimilasi spesies, dan seorang eksekutor armada Protoss yang bertugas melindungi Protoss dari Zerg. StarCraft segera mendapat pujian kritis, memenangkan banyak penghargaan, termasuk disebut sebagai \"permainan strategi waktu nyata terbaik yang pernah dibuat\".', 'https://www.youtube.com/watch?v=F-7CuVmis5w', 'Windows', '/resources/images/covers/starcraft-cover.jpg', '/resources/images/starcraft-1.jpg', '/resources/images/starcraft-2.jpg', '/resources/images/starcraft-3.jpg', '/resources/images/starcraft-4.jpg', 'https://battle.net/download/getInstallerForGame?os=WIN&version=LIVE&gameProgram=STARCRAFT'),
(12, 'Alien Arena', 5.50, 'Apakah Anda menyukai pertarungan kematian ala sekolah lama dengan fitur-fitur modern? Bagaimana dengan atmosfer berwarna-warni, kental seperti di dalam arkade? Bagaimana kalau... gaya retro Sci Fi? Maka Anda akan menyukai apa yang Alien Arena tawarkan untuk Anda! Permainan ini menggabungkan beberapa aspek terbaik dari permainan seperti Quake III dan Unreal Tournament dan membungkusnya dengan tema alien retro, sambil menambahkan banyak ide asli untuk membuat permainan ini sangat unik. Alien Arena adalah pertarungan seru dengan arena yang bervariasi dari yang kecil hingga besar. Dengan basis pemain yang besar, tidak pernah sulit untuk menemukan pertandingan yang seru, kapan pun dalam sehari. Komunitasnya ramah, serta produktif. Puluhan peta, model, dan berbagai aksesori telah dibuat oleh anggota komunitas untuk menambah pengalaman bermain game.', 'https://www.youtube.com/watch?v=YNvep_oWFbs', 'Linux', '/resources/images/covers/alien-arena-cover.jpg', '/resources/images/alien-arena-1.jpg', '/resources/images/alien-arena-2.jpg', '/resources/images/alien-arena-3.jpg', '/resources/images/alien-arena-4.jpg', 'http://localhost/games/alienarena-7.66-linux.tar.gz'),
(13, 'Smokin\' Guns', 8.50, 'Smokin\' Guns (SG) adalah permainan video penembak orang pertama. Smokin\' Guns dimaksudkan sebagai simulasi semi-realistis dari atmosfer \"Old West\" dan dikembangkan menggunakan mesin Quake III Arena milik id Software. Gameplay serta lokasi terinspirasi oleh film-film Barat, terutama dari genre Italowestern atau Spaghetti Western. Berikut adalah beberapa fitur paling penting dari Smokin\' Guns:\r\n- Arsenal lengkap senjata dengan desain yang sesuai secara historis. Lihat halaman senjata untuk informasi lebih lanjut.\r\n- Berbagai peta dan model pemain bergaya Barat.\r\n- Sistem kerusakan realistis dengan lokasi yang berbeda (kepala, dada, leher, dll.) dan kerusakan jatuh tergantung tinggi.\r\n- Mode permainan bergaya Barat baru untuk kesenangan lebih: Perampokan Bank dan Mode Duel.\r\n- Sistem uang yang memungkinkan pembelian peralatan dengan uang dari hadiah & pickup.\r\n- Antarmuka pengguna grafis dan HUD yang mudah digunakan.\r\n- Peningkatan kecil lainnya untuk gameplay yang lebih baik dan kesenangan yang lebih meningkat.', 'https://www.youtube.com/watch?v=RGIYZf-BBfA', 'Linux', '/resources/images/covers/smokin-guns-cover.jpg', '/resources/images/smokin-guns-1.jpg', '/resources/images/smokin-guns-2.jpg', '/resources/images/smokin-guns-3.jpg', '/resources/images/smokin-guns-4.jpg', 'https://www.smokin-guns.org/downloads/Smokin_Guns_1.1.zip');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CustomerID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `ProductID` (`ProductID`),
  ADD KEY `CustomerID` (`CustomerID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`ProductID`) REFERENCES `products` (`ProductID`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`CustomerID`) REFERENCES `customers` (`CustomerID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
